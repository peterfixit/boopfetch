/* Small POSIX/Linux bridge for Boopfetch's Fortran implementation.
   These calls use the Linux C library only; no external commands or third-party libraries. */
#define _GNU_SOURCE
#include <stdio.h>
#include <stdlib.h>
#include <stdint.h>
#include <string.h>
#include <unistd.h>
#include <dirent.h>
#include <sys/statvfs.h>
#include <sys/ioctl.h>
#include <net/if.h>
#include <ifaddrs.h>
#include <arpa/inet.h>
#include <netinet/in.h>
#include <sys/socket.h>

int bf_ttycols(void) {
    struct winsize w;
    if (ioctl(STDOUT_FILENO, TIOCGWINSZ, &w) == 0 && w.ws_col >= 40) return w.ws_col;
    const char *p = getenv("COLUMNS");
    int v = p ? atoi(p) : 0;
    return v >= 40 && v < 2000 ? v : 148;
}
int bf_isatty(void) { return isatty(STDOUT_FILENO); }

int bf_listdir(const char *path, char *dest, int capacity) {
    if (!dest || capacity < 2) return -1;
    dest[0] = 0;
    DIR *d = opendir(path);
    if (!d) return -1;
    int used = 0;
    struct dirent *e;
    while ((e = readdir(d))) {
        if (!strcmp(e->d_name,".") || !strcmp(e->d_name,"..")) continue;
        int n = (int)strlen(e->d_name);
        if (used + n + 2 >= capacity) break;
        memcpy(dest+used,e->d_name,n);
        used += n;
        dest[used++] = '\n';
        dest[used] = 0;
    }
    closedir(d);
    return used;
}

int bf_fs_stats(const char *path, int64_t *total, int64_t *used, int64_t *available) {
    struct statvfs fs;
    if (statvfs(path,&fs) != 0) return -1;
    uint64_t block = fs.f_frsize ? fs.f_frsize : fs.f_bsize;
    *total = (int64_t)((uint64_t)fs.f_blocks * block);
    *used = (int64_t)((uint64_t)(fs.f_blocks - fs.f_bfree) * block);
    *available = (int64_t)((uint64_t)fs.f_bavail * block);
    return 0;
}

/* Gather IP addresses without using ip, ifconfig, or any other executable.
   One line per address: name|4/6|address/prefix\n. */
int bf_ifaddrs(char *dest, int capacity) {
    if (!dest || capacity < 2) return -1;
    dest[0] = 0;
    struct ifaddrs *head = NULL;
    if (getifaddrs(&head) != 0) return -1;
    int used = 0;
    for (struct ifaddrs *p = head; p; p = p->ifa_next) {
        if (!p->ifa_addr || !p->ifa_name || !strcmp(p->ifa_name,"lo")) continue;
        int family = p->ifa_addr->sa_family;
        if (family != AF_INET && family != AF_INET6) continue;
        char ip[INET6_ADDRSTRLEN];
        int bits = 0;
        const void *addr;
        if (family == AF_INET) {
            addr = &((struct sockaddr_in *)p->ifa_addr)->sin_addr;
            if (p->ifa_netmask) {
                uint32_t mask = ntohl(((struct sockaddr_in *)p->ifa_netmask)->sin_addr.s_addr);
                bits = __builtin_popcount(mask);
            }
        } else {
            addr = &((struct sockaddr_in6 *)p->ifa_addr)->sin6_addr;
            if (p->ifa_netmask) {
                const uint8_t *b = ((const struct sockaddr_in6 *)p->ifa_netmask)->sin6_addr.s6_addr;
                for (int k=0;k<16;k++) bits += __builtin_popcount((unsigned)b[k]);
            }
        }
        if (!inet_ntop(family, addr, ip, sizeof(ip))) continue;
        /* Ignore IPv6 link-local; it adds clutter and is rarely useful in a fetch display. */
        if (family == AF_INET6 && !strncmp(ip,"fe80:",5)) continue;
        char line[256];
        int n = snprintf(line,sizeof(line),"%s|%d|%s/%d\n",p->ifa_name,family==AF_INET?4:6,ip,bits);
        if (n <= 0 || n >= (int)sizeof(line) || used+n+1 >= capacity) continue;
        memcpy(dest+used,line,n);
        used += n;
        dest[used] = 0;
    }
    freeifaddrs(head);
    return used;
}

/* /proc/cpuinfo can report st_size=0. GNU Fortran's formatted I/O can
   treat it as EOF on some containerized procfs implementations, so use
   sequential libc fgets as a narrow fallback for this kernel file. */
int bf_cpuinfo(char *dest, int capacity) {
    if (!dest || capacity < 2) return 0;
    dest[0]=0;
    FILE *f = fopen("/proc/cpuinfo", "r");
    if (!f) return 0;
    char line[2048];
    int processors=0;
    while (fgets(line,sizeof(line),f)) {
        char *sep = strchr(line,':');
        if (!sep) continue;
        *sep++=0;
        char *key=line;
        while (*key==' ' || *key=='\t') key++;
        size_t z=strlen(key);
        while (z && (key[z-1]==' ' || key[z-1]=='\t')) key[--z]=0;
        if (!strcmp(key,"processor")) processors++;
        if ((!strcmp(key,"model name") || !strcmp(key,"Hardware")) && !dest[0]) {
            while (*sep==' ' || *sep=='\t') sep++;
            size_t n=strcspn(sep,"\r\n");
            if (n>=(size_t)capacity) n=capacity-1;
            memcpy(dest,sep,n);dest[n]=0;
        }
    }
    fclose(f);
    return processors;
}

/* Directory counts are streamed so a system with many packages cannot
   silently lose packages to a fixed output buffer. */
int bf_dircount(const char *path) {
    DIR *d=opendir(path);
    if (!d) return -1;
    struct dirent *e;
    int count=0;
    while((e=readdir(d))) {
        if (e->d_name[0]=='.' || !strcmp(e->d_name,"ALPM_DB_VERSION")) continue;
        if (e->d_type==DT_DIR || e->d_type==DT_UNKNOWN) count++;
    }
    closedir(d);
    return count;
}
int bf_package_version(const char *path, const char *package, char *out, int capacity) {
    if (!out || capacity<2) return 0;
    out[0]=0;
    DIR *d=opendir(path);
    if(!d) return 0;
    struct dirent *e;
    int prefix=(int)strlen(package);
    while ((e=readdir(d))) {
        if(strncmp(e->d_name,package,prefix)!=0 || e->d_name[prefix]!='-') continue;
        const char *version=e->d_name+prefix+1;
        int n=(int)strlen(version);
        const char *end=strrchr(version,'-');
        if(end && end>version) n=(int)(end-version);
        if(n>=capacity) n=capacity-1;
        memcpy(out,version,n);
        out[n]=0;
        closedir(d);
        return n;
    }
    closedir(d);
    return 0;
}
