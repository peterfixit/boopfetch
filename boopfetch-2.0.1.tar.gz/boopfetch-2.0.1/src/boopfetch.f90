! Boopfetch 2.0 -- a standalone Linux system-information dashboard.
! Copyright (c) 2026 Boopfetch contributors. MIT License.
! Core collection is implemented in Fortran. linux_bridge.c supplies a few
! direct POSIX/Linux calls. No external programs, network requests, or root.
module boopfetch
  use iso_fortran_env, only: int64, real64, output_unit
  use iso_c_binding, only: c_char, c_int, c_int64_t, c_null_char
  implicit none
  private
  integer, parameter :: ng=7, maxitems=120, maxwarn=100, maxlines=256
  integer, parameter :: SYSTEM=1, HARDWARE=2, DESKTOP=3, STORAGE=4, NETWORK=5, PACKAGES=6, HEALTH=7
  character(len=*), parameter :: ESC=achar(27)//'['
  character(len=*), parameter :: CYAN='38;2;68;224;232', PURPLE='38;2;210;113;255', &
      WHITE='38;2;234;240;251', MUTED='38;2;145;158;175', GREEN='38;2;89;224;174', &
      GOLD='38;2;255;204;99', RED='38;2;255;110;135', BLUE='38;2;132;179;255'
  type kv
    character(len=60) :: label=''
    character(len=700) :: value=''
    integer :: level=0
  end type
  type category
    character(len=40) :: name=''
    character(len=8) :: symbol=''
    integer :: count=0
    type(kv) :: entries(maxitems)
  end type
  type strline
    character(len=4096) :: s=''
  end type
  type category_block
    type(strline) :: lines(maxlines)
    integer :: count=0
  end type
  type(category) :: g(ng)
  character(len=256) :: notices(maxwarn)=''
  integer :: notice_n=0, warning_n=0, warn_disk=5, terminal_width=148
  logical :: use_color=.false., brief=.false., health_flag=.false., json_flag=.false., show_ipv6=.false.
  logical :: detected_temps=.false.
  character(len=48) :: logo_opt='boop'
  character(len=512) :: logo_path=''
  interface
    integer(c_int) function bf_ttycols() bind(C,name='bf_ttycols')
      import c_int
    end function
    integer(c_int) function bf_isatty() bind(C,name='bf_isatty')
      import c_int
    end function
    integer(c_int) function bf_listdir(path,buffer,cap) bind(C,name='bf_listdir')
      import c_int,c_char
      character(kind=c_char),intent(in) :: path(*)
      character(kind=c_char),intent(out)::buffer(*)
      integer(c_int),value :: cap
    end function
    integer(c_int) function bf_fs_stats(path,total,used,avail) bind(C,name='bf_fs_stats')
      import c_int,c_char,c_int64_t
      character(kind=c_char),intent(in)::path(*)
      integer(c_int64_t),intent(out)::total,used,avail
    end function
    integer(c_int) function bf_ifaddrs(buffer,cap) bind(C,name='bf_ifaddrs')
      import c_int,c_char
      character(kind=c_char),intent(out)::buffer(*)
      integer(c_int),value::cap
    end function
    integer(c_int) function bf_cpuinfo(buffer,cap) bind(C,name='bf_cpuinfo')
      import c_int,c_char
      character(kind=c_char),intent(out)::buffer(*)
      integer(c_int),value::cap
    end function
    integer(c_int) function bf_dircount(path) bind(C,name='bf_dircount')
      import c_int,c_char
      character(kind=c_char),intent(in)::path(*)
    end function
    integer(c_int) function bf_package_version(path,pkg,out,cap) bind(C,name='bf_package_version')
      import c_int,c_char
      character(kind=c_char),intent(in)::path(*),pkg(*)
      character(kind=c_char),intent(out)::out(*)
      integer(c_int),value::cap
    end function
  end interface
  public :: run
contains
  subroutine run()
    integer :: i,ios
    character(len=512) :: a
    logical :: force_color, no_color
    force_color=.false.;no_color=.false.
    call init_groups()
    do i=1,command_argument_count()
      call get_command_argument(i,a)
      select case(trim(a))
      case('--help','-h'); call help();return
      case('--version','-v'); print '(A)', 'Boopfetch 2.0.1 (Fortran, Linux, standalone)';return
      case('--temp-help'); call temp_help();return
      case('--install-temps'); call install_temps();return
      case('--json'); json_flag=.true.
      case('--health'); health_flag=.true.
      case('--brief'); brief=.true.
      case('--ipv6'); show_ipv6=.true.
      case('--color'); force_color=.true.
      case('--plain','--no-color');no_color=.true.
      case default
        if(index(a,'--logo=')==1) then
          logo_opt=trim(a(8:))
          if(logo_opt/='boop'.and.logo_opt/='loader'.and.logo_opt/='none') then
            print '(A)', 'Unknown logo. Use boop, loader or none.';stop 2
          end if
        else if(index(a,'--logo-file=')==1) then
          logo_path=a(13:)
        else if(index(a,'--warn-disk=')==1) then
          read(a(13:),*,iostat=ios) warn_disk
          if(ios/=0) then
            print '(A)', 'Invalid --warn-disk value.';stop 2
          end if
          if(warn_disk<1.or.warn_disk>99) then
            print '(A)', '--warn-disk must be 1..99.';stop 2
          end if
        else if(index(a,'--width=')==1) then
          read(a(9:),*,iostat=ios) terminal_width
          if(ios/=0) then
            print '(A)', 'Invalid --width value.';stop 2
          end if
          if(terminal_width<55.or.terminal_width>300) then
            print '(A)', '--width must be between 55 and 300.';stop 2
          end if
        else
          print '(A)', 'Unknown option: '//trim(a)//'. Use --help.';stop 2
        end if
      end select
    end do
    use_color=bf_isatty()/=0
    if(len_trim(env('NO_COLOR'))>0.or.trim(env('TERM'))=='dumb') use_color=.false.
    if(force_color) use_color=.true.
    if(no_color.or.json_flag) use_color=.false.
    if(.not.has_width_argument()) terminal_width=max(55,min(220,int(bf_ttycols())))
    call collect()
    if(json_flag) then
      call output_json()
    else if(brief) then
      call output_brief()
    else
      call output_dashboard()
    end if
  end subroutine

  logical function has_width_argument() result(found)
    integer :: i
    character(len=512):: a
    found=.false.
    do i=1,command_argument_count()
      call get_command_argument(i,a)
      if(index(a,'--width=')==1) found=.true.
    end do
  end function

  subroutine init_groups()
    g(SYSTEM)%name='System';g(SYSTEM)%symbol='◇'
    g(HARDWARE)%name='Hardware';g(HARDWARE)%symbol='▣'
    g(DESKTOP)%name='Desktop';g(DESKTOP)%symbol='▤'
    g(STORAGE)%name='Storage';g(STORAGE)%symbol='▰'
    g(NETWORK)%name='Network';g(NETWORK)%symbol='◎'
    g(PACKAGES)%name='Packages';g(PACKAGES)%symbol='▦'
    g(HEALTH)%name='Health';g(HEALTH)%symbol='♡'
  end subroutine

  subroutine help()
    print '(A)', 'Boopfetch 2.0.1 - a neon-styled Linux system fetch, written in Fortran'
    print '(A)', 'Usage: boopfetch [options]'
    print '(A)', '  --logo=boop|loader|none     Original cat, loader, or no artwork'
    print '(A)', '  --logo-file=PATH           Plain-text UTF-8 custom artwork'
    print '(A)', '  --health                   Explain health warnings and unavailable checks'
    print '(A)', '  --warn-disk=N              Disk free-space warning threshold (default 5%)'
    print '(A)', '  --ipv6                     Also show non-link-local IPv6 addresses'
    print '(A)', '  --temp-help                Show optional sensor-monitoring installation steps'
    print '(A)', '  --install-temps            Offer to install lm_sensors (requires approval)'
    print '(A)', '  --width=N                  Set dashboard width (55..300 columns)'
    print '(A)', '  --brief                    Compact output'
    print '(A)', '  --json                     Structured JSON output'
    print '(A)', '  --plain / --color          Disable / enable ANSI colours'
    print '(A)', '  -v / -h                    Version / help'
    print '(A)', 'Core display requires no additional executable, libraries or network access.'
  end subroutine

  function env(key) result(value)
    character(len=*),intent(in)::key
    character(len=256)::value
    integer::ios
    value='';call get_environment_variable(key,value,status=ios)
    if(ios/=0) value=''
    value=trim(value)
  end function

  function first(path) result(value)
    character(len=*),intent(in)::path
    character(len=512)::value
    integer::u,ios
    value=''
    open(newunit=u,file=trim(path),status='old',action='read',iostat=ios)
    if(ios/=0) return
    read(u,'(A)',iostat=ios) value
    close(u)
    if(ios/=0) value=''
    value=trim(adjustl(value))
  end function

  function num(n) result(s)
    integer,intent(in)::n
    character(len=32)::s
    write(s,'(I0)') n
  end function

  function num64(n) result(s)
    integer(int64),intent(in)::n
    character(len=40)::s
    write(s,'(I0)') n
  end function

  function fixed(x) result(s)
    real(real64),intent(in)::x
    character(len=30)::s
    write(s,'(F0.1)') x
    s=adjustl(s)
    if(s(1:1)=='.') s='0'//trim(s)
    if(s(1:2)=='-.') s='-0'//trim(s(2:))
  end function

  function bytes_str(b) result(v)
    integer(int64),intent(in)::b
    character(len=60)::v
    real(real64)::x
    x=real(max(0_int64,b),real64)
    if(x>=1024.0_real64**4) then
      v=trim(fixed(x/1024.0_real64**4))//' TiB'
    else if(x>=1024.0_real64**3) then
      v=trim(fixed(x/1024.0_real64**3))//' GiB'
    else if(x>=1024.0_real64**2) then
      v=trim(fixed(x/1024.0_real64**2))//' MiB'
    else if(x>=1024.0_real64) then
      v=trim(fixed(x/1024.0_real64))//' KiB'
    else
      v=trim(num64(b))//' B'
    end if
  end function

  function kib_str(k) result(v)
    integer(int64),intent(in)::k
    character(len=60)::v
    v=bytes_str(k*1024_int64)
  end function

  subroutine add(section,label,value,level)
    integer,intent(in)::section
    character(len=*),intent(in)::label,value
    integer,optional,intent(in)::level
    integer::i
    if(len_trim(value)==0) return
    i=g(section)%count+1
    if(i>maxitems) return
    g(section)%count=i
    g(section)%entries(i)%label=trim(label)
    g(section)%entries(i)%value=trim(value)
    if(present(level)) g(section)%entries(i)%level=level
  end subroutine

  subroutine warn(s)
    character(len=*),intent(in)::s
    warning_n=warning_n+1
    if(notice_n>=maxwarn) return
    notice_n=notice_n+1
    notices(notice_n)=trim(s)
  end subroutine

  function list_dir(path) result(value)
    character(len=*),intent(in)::path
    character(len=32768)::value
    character(kind=c_char)::buf(32768)
    integer::n,i
    value='';buf=c_null_char
    n=int(bf_listdir(trim(path)//c_null_char,buf,int(size(buf),c_int)))
    if(n<=0) return
    do i=1,min(n,len(value))
      value(i:i)=buf(i)
    end do
  end function

  ! Return next newline-delimited item from a string, advancing cursor.
  subroutine next_line(data,pos,item)
    character(len=*),intent(in)::data
    integer,intent(inout)::pos
    character(len=*),intent(out)::item
    integer::a,b
    item=''
    if(pos>len_trim(data)) return
    a=pos;b=index(data(a:),achar(10))
    if(b==0) then
      item=trim(data(a:));pos=len_trim(data)+1
    else
      item=trim(data(a:a+b-2));pos=a+b
    end if
  end subroutine

  function token(s,n) result(v)
    character(len=*),intent(in)::s
    integer,intent(in)::n
    character(len=512)::v
    integer::i,j,k,l
    v='';k=0;l=len_trim(s);i=1
    do while(i<=l)
      if(s(i:i)==' '.or.s(i:i)==achar(9)) then
        i=i+1;cycle
      end if
      j=i
      do while(j<=l)
        if(s(j:j)==' '.or.s(j:j)==achar(9)) exit
        j=j+1
      end do
      k=k+1
      if(k==n) then
        v=s(i:j-1);return
      end if
      i=j+1
    end do
  end function

  function after(s,delimiter) result(v)
    character(len=*),intent(in)::s,delimiter
    character(len=512)::v
    integer::i
    v='';i=index(s,delimiter)
    if(i>0) v=trim(adjustl(s(i+len(delimiter):)))
  end function

  function os_value(key) result(v)
    character(len=*),intent(in)::key
    character(len=512)::v,line
    integer::u,ios,i,l
    v=''
    open(newunit=u,file='/etc/os-release',status='old',action='read',iostat=ios)
    if(ios/=0) return
    do
      read(u,'(A)',iostat=ios) line
      if(ios/=0) exit
      i=index(line,'=')
      if(i<2) cycle
      if(trim(line(:i-1))/=key) cycle
      v=trim(adjustl(line(i+1:)))
      l=len_trim(v)
      if(l>=2) then
        if(v(1:1)=='"'.and.v(l:l)=='"') v=v(2:l-1)
      end if
      exit
    end do
    close(u)
  end function

  function os_name() result(v)
    character(len=512)::v
    v=os_value('PRETTY_NAME')
    if(len_trim(v)==0) v='Linux'
  end function

  subroutine collect()
    character(len=512)::host,uname_val,kern,arch,upt
    host=first('/proc/sys/kernel/hostname')
    uname_val=env('USER')
    if(len_trim(uname_val)==0) uname_val='user'
    if(len_trim(host)==0) host='linux'
    call add(SYSTEM,'System',trim(uname_val)//'@'//trim(host))
    call add(SYSTEM,'OS',trim(os_name()))
    call add(SYSTEM,'Host',trim(host_model()))
    kern=first('/proc/sys/kernel/osrelease')
    call add(SYSTEM,'Kernel',trim(kern))
    arch='x86_64';if(index(kern,'aarch64')>0) arch='aarch64'
    arch=first('/proc/sys/kernel/arch')
    if(len_trim(arch)==0) then
      ! In practice uname gives this, but do not depend on its executable.
      arch=trim(architecture())
    end if
    call add(SYSTEM,'Architecture',trim(arch))
    call load_uptime()
    call load_cpu()
    call load_memory()
    call load_gpu()
    call load_desktop()
    call load_mounts()
    call load_network()
    call load_packages()
    call load_sensors()
    call load_battery()
    call add(PACKAGES,'Failed services','Not queried (no external tools)')
    if(warning_n==0) then
      call add(HEALTH,'Health checks','No triggered warnings',1)
    else
      call add(HEALTH,'Health checks',trim(num(warning_n))//' warning(s)',2)
    end if
  end subroutine

  function architecture() result(v)
    character(len=32)::v
    ! This build currently targets x86-64 and uses the architecture of the binary.
    v='x86_64'
  end function

  function host_model() result(v)
    character(len=512)::v,a,b
    a=first('/sys/class/dmi/id/product_name')
    b=first('/sys/class/dmi/id/product_version')
    v=a
    if(len_trim(b)>0.and.b/=a.and.b/='None'.and.b/='Not Specified') then
      if(index(b,'ThinkPad')>0.or.index(b,'Latitude')>0) then
        v=trim(b)//' ('//trim(a)//')'
      else
        v=trim(a)//' '//trim(b)
      end if
    end if
    if(len_trim(v)==0) v=first('/sys/class/dmi/id/board_name')
    if(len_trim(v)==0) v='Unknown'
  end function

  subroutine load_uptime()
    character(len=512)::s
    real(real64)::sec,l1,l5,l15
    integer::ios,u
    s=first('/proc/uptime')
    read(s,*,iostat=ios) sec
    if(ios==0) then
      call add(SYSTEM,'Uptime',trim(num(int(sec/86400)))//'d '// &
          trim(num(mod(int(sec/3600),24)))//'h '//trim(num(mod(int(sec/60),60)))//'m')
    end if
    s=first('/proc/loadavg')
    read(s,*,iostat=ios) l1,l5,l15
    if(ios==0) call add(SYSTEM,'Load (1/5/15m)',trim(fixed(l1))//' / '//trim(fixed(l5))//' / '//trim(fixed(l15)))
  end subroutine

  subroutine load_cpu()
    integer::u,ios,colon,cpus,now_k,max_k,j
    character(kind=c_char)::cmodel(512)
    character(len=1024)::line
    character(len=512)::model,s1,s2
    model='';cpus=0
    open(newunit=u,file='/proc/cpuinfo',status='old',action='read',iostat=ios)
    if(ios==0) then
      do
        read(u,'(A)',iostat=ios) line
        if(ios/=0) exit
        colon=index(line,':');if(colon<2) cycle
        if(trim(adjustl(line(:colon-1)))=='processor') cpus=cpus+1
        if(trim(adjustl(line(:colon-1)))=='model name'.and.len_trim(model)==0) model=trim(adjustl(line(colon+1:)))
      end do
      close(u)
    end if
    if(cpus==0.or.len_trim(model)==0) then
      cmodel=c_null_char
      cpus=int(bf_cpuinfo(cmodel,int(size(cmodel),c_int)))
      model=''
      do j=1,size(cmodel)
        if(cmodel(j)==c_null_char) exit
        model(j:j)=cmodel(j)
      end do
    end if
    if(len_trim(model)==0) model=first('/proc/device-tree/model')
    if(len_trim(model)==0) model='Unknown CPU'
    call add(HARDWARE,'CPU',trim(model)//' ('//trim(num(cpus))//' threads)')
    s1=first('/sys/devices/system/cpu/cpu0/cpufreq/scaling_cur_freq')
    read(s1,*,iostat=ios) now_k
    if(ios/=0) now_k=0
    s2=first('/sys/devices/system/cpu/cpu0/cpufreq/cpuinfo_max_freq')
    read(s2,*,iostat=ios) max_k
    if(ios/=0) max_k=0
    line=''
    if(now_k>0) line=trim(fixed(real(now_k,real64)/1.0e6_real64))//' GHz current'
    if(max_k>0) then
      if(len_trim(line)>0) line=trim(line)//' / '
      line=trim(line)//trim(fixed(real(max_k,real64)/1.0e6_real64))//' GHz rated max'
    end if
    call add(HARDWARE,'Frequency',trim(line))
  end subroutine

  subroutine load_memory()
    integer(int64)::memtotal,memavail,swaptotal,swapfree,n
    integer::u,ios,i
    character(len=1024)::line,key
    memtotal=0;memavail=0;swaptotal=0;swapfree=0
    open(newunit=u,file='/proc/meminfo',status='old',action='read',iostat=ios)
    if(ios/=0) return
    do
      read(u,'(A)',iostat=ios) line
      if(ios/=0) exit
      i=index(line,':');if(i<1) cycle
      key=line(:i-1)
      read(line(i+1:),*,iostat=ios) n
      if(ios/=0) cycle
      select case(trim(key))
      case('MemTotal'); memtotal=n
      case('MemAvailable');memavail=n
      case('SwapTotal');swaptotal=n
      case('SwapFree');swapfree=n
      end select
    end do
    close(u)
    if(memtotal>0) then
      i=nint(100.0_real64*real(memtotal-memavail,real64)/real(memtotal,real64))
      call add(HARDWARE,'RAM',trim(kib_str(memtotal-memavail))//' / '//trim(kib_str(memtotal))// &
          ' ('//trim(num(i))//'% used)',merge(2,0,i>=90))
      if(i>=90) call warn('High RAM usage: '//trim(num(i))//'%')
    end if
    if(swaptotal>0) then
      i=nint(100.0_real64*real(swaptotal-swapfree,real64)/real(swaptotal,real64))
      call add(STORAGE,'Swap',trim(kib_str(swaptotal-swapfree))//' / '//trim(kib_str(swaptotal))// &
          ' ('//trim(num(i))//'% used)')
    else
      call add(STORAGE,'Swap','Not configured')
    end if
  end subroutine

  function version_from_pacman(package) result(v)
    character(len=*),intent(in)::package
    character(len=128)::v
    character(kind=c_char)::out(128)
    integer::n,i
    out=c_null_char;v=''
    n=int(bf_package_version('/var/lib/pacman/local'//c_null_char,trim(package)//c_null_char, &
        out,int(size(out),c_int)))
    if(n<=0) return
    do i=1,min(n,len(v))
      v(i:i)=out(i)
    end do
  end function

  subroutine load_desktop()
    character(len=512)::desktop_name,s,v,terminal,display,entry
    character(len=32768)::items
    integer::i,pos
    desktop_name=env('XDG_CURRENT_DESKTOP')
    if(len_trim(desktop_name)==0) desktop_name=env('DESKTOP_SESSION')
    if(index(desktop_name,'KDE')>0.or.index(desktop_name,'Plasma')>0) then
      s=version_from_pacman('plasma-workspace')
      desktop_name='KDE Plasma'
      if(len_trim(s)>0) desktop_name=trim(desktop_name)//' '//trim(s)
    end if
    call add(DESKTOP,'Desktop',trim(desktop_name))
    call add(DESKTOP,'Session',trim(env('XDG_SESSION_TYPE')))
    call add(DESKTOP,'Shell',trim(env('SHELL')))
    terminal=''
    if(len_trim(env('KONSOLE_VERSION'))>0) terminal='Konsole'
    if(len_trim(env('TERM_PROGRAM'))>0) terminal=env('TERM_PROGRAM')
    if(len_trim(env('KITTY_WINDOW_ID'))>0) terminal='Kitty'
    if(len_trim(env('ALACRITTY_WINDOW_ID'))>0) terminal='Alacritty'
    if(len_trim(terminal)==0) terminal=env('TERM')
    call add(DESKTOP,'Terminal',trim(terminal))
    v=env('LC_ALL');if(len_trim(v)==0) v=env('LANG')
    call add(DESKTOP,'Locale',trim(v))
    items=list_dir('/sys/class/drm');pos=1
    do
      call next_line(items,pos,entry)
      if(len_trim(entry)==0) exit
      if(index(entry,'-eDP-')==0.and.index(entry,'-HDMI-')==0.and.index(entry,'-DP-')==0) cycle
      display=first('/sys/class/drm/'//trim(entry)//'/modes')
      if(len_trim(display)==0) cycle
      call add(DESKTOP,'Display',trim(entry)//' '//trim(display))
      exit
    end do
  end subroutine

  subroutine load_gpu()
    character(len=32768)::devices
    character(len=512)::device,b,cls,vendor,chip,model,desc
    integer::pos
    devices=list_dir('/sys/bus/pci/devices');pos=1
    do
      call next_line(devices,pos,device)
      if(len_trim(device)==0) exit
      b='/sys/bus/pci/devices/'//trim(device)//'/'
      cls=first(trim(b)//'class')
      if(index(cls,'0x03')/=1) cycle
      vendor=first(trim(b)//'vendor')
      chip=first(trim(b)//'device')
      select case(trim(vendor))
      case('0x1002');model='AMD Radeon'
      case('0x10de');model='NVIDIA GeForce/Quadro'
      case('0x8086');model='Intel Graphics'
      case default; model='PCI graphics device'
      end select
      desc=pci_description(vendor,chip)
      if(len_trim(desc)>0) then
        model=trim(desc)
      else if(trim(vendor)=='0x1002'.and.trim(chip)=='0x1681') then
        model='AMD Rembrandt (Radeon 680M)'
      end if
      call add(HARDWARE,'GPU',trim(model)//' ['//trim(vendor)//':'//trim(chip)//']')
    end do
  end subroutine

  function pci_description(vendor,device) result(desc)
    character(len=*),intent(in)::vendor,device
    character(len=512)::desc,ln,filepath
    integer::i,u,ios
    logical::inside
    desc='';inside=.false.
    filepath=''
    if(len_trim(first('/usr/share/hwdata/pci.ids'))>0) filepath='/usr/share/hwdata/pci.ids'
    if(len_trim(filepath)==0) then
      inquire(file='/usr/share/hwdata/pci.ids',exist=inside)
      if(inside) filepath='/usr/share/hwdata/pci.ids'
    end if
    if(len_trim(filepath)==0) then
      inquire(file='/usr/share/misc/pci.ids',exist=inside)
      if(inside) filepath='/usr/share/misc/pci.ids'
    end if
    if(len_trim(filepath)==0) return
    open(newunit=u,file=trim(filepath),status='old',action='read',iostat=ios)
    if(ios/=0) return
    inside=.false.
    do
      read(u,'(A)',iostat=ios) ln
      if(ios/=0) exit
      if(len_trim(ln)<5) cycle
      if(ln(1:1)/=achar(9).and.ln(1:1)/=' '.and.ln(1:1)/='#') then
        inside=ln(1:4)==vendor(3:6)
      else if(inside.and.ln(1:1)==achar(9)) then
        if(ln(2:2)==achar(9)) cycle
        if(ln(2:5)==device(3:6)) then
          desc=trim(adjustl(ln(6:)))
          exit
        end if
      end if
    end do
    close(u)
  end function

  ! Decode the escaped blanks used by /proc/self/mountinfo.
  function mount_path_escaped(v) result(s)
    character(len=*),intent(in)::v
    character(len=512)::s
    integer::i,j,n
    s='';i=1;j=0;n=len_trim(v)
    do while(i<=n.and.j<len(s))
      j=j+1
      if(i+3<=n) then
        if(v(i:i+3)==achar(92)//'040') then
          s(j:j)=' ';i=i+4;cycle
        end if
      end if
      s(j:j)=v(i:i);i=i+1
    end do
  end function

  logical function regular_fs(mnt,typ) result(ok)
    character(len=*),intent(in)::mnt,typ
    ok=.false.
    if(mnt=='/') then
      ok=.true.;return
    end if
    if(index(mnt,'/run')==1.and.index(mnt,'/run/media/')/=1) return
    if(index(mnt,'/sys')==1.or.index(mnt,'/proc')==1.or.index(mnt,'/dev')==1) return
    select case(trim(typ))
    case('ext2','ext3','ext4','btrfs','xfs','zfs','vfat','msdos','ntfs','ntfs3','fuseblk', &
        'exfat','f2fs','bcachefs','cifs','smb3','nfs','nfs4','9p','udf','iso9660', &
        'fuse.sshfs','fuse.rclone','fuse.mergerfs','fuse.zfs','fuse.glusterfs')
      ok=.true.
    case default
      if(index(typ,'fuse.')==1) ok=.true.
    end select
  end function

  subroutine mount_record(path,typ,seen,nseen)
    character(len=*),intent(in)::path,typ
    character(len=512),intent(inout)::seen(:)
    integer,intent(inout)::nseen
    integer(int64)::total,used,avail
    character(len=512)::value
    integer::percent,free_percent,i,rc
    do i=1,nseen
      if(trim(seen(i))==trim(path)) return
    end do
    if(nseen>=size(seen)) return
    nseen=nseen+1;seen(nseen)=path
    rc=int(bf_fs_stats(trim(path)//c_null_char,total,used,avail))
    if(rc/=0.or.total<=0) then
      call add(STORAGE,trim(path),'Usage unavailable ('//trim(typ)//')')
      return
    end if
    percent=nint(100.0_real64*real(used,real64)/real(total,real64))
    free_percent=nint(100.0_real64*real(avail,real64)/real(total,real64))
    value=trim(bytes_str(used))//' / '//trim(bytes_str(total))// &
        ' ('//trim(num(percent))//'% used, '//trim(num(free_percent))//'% free; '//trim(typ)//')'
    call add(STORAGE,trim(path),trim(value),merge(2,0,free_percent<=warn_disk))
    if(free_percent<=warn_disk) call warn('Low disk space: '//trim(path)//' ('//trim(num(free_percent))//'% free)')
  end subroutine

  subroutine load_mounts()
    character(len=8192)::line
    character(len=512)::point,typ,tail,s
    character(len=512)::seen(128)
    integer::u,ios,p,count
    count=0;seen=''
    open(newunit=u,file='/proc/self/mountinfo',status='old',action='read',iostat=ios)
    if(ios/=0) return
    ! Print root first for readability.
    do
      read(u,'(A)',iostat=ios) line
      if(ios/=0) exit
      p=index(line,' - ')
      if(p==0) cycle
      point=mount_path_escaped(token(line(:p-1),5))
      if(trim(point)/='/') cycle
      typ=token(line(p+3:),1)
      call mount_record('/',trim(typ),seen,count)
      exit
    end do
    rewind(u)
    do
      read(u,'(A)',iostat=ios) line
      if(ios/=0) exit
      p=index(line,' - ')
      if(p==0) cycle
      point=mount_path_escaped(token(line(:p-1),5))
      typ=token(line(p+3:),1)
      if(.not.regular_fs(trim(point),trim(typ))) cycle
      call mount_record(trim(point),trim(typ),seen,count)
    end do
    close(u)
    call add(STORAGE,'Regular mounts',trim(num(count))//' filesystem(s)')
  end subroutine

  function network_class(iface) result(name)
    character(len=*),intent(in)::iface
    character(len=30)::name
    character(len=512)::typ
    logical::exists
    name='NET'
    typ=first('/sys/class/net/'//trim(iface)//'/type')
    inquire(file='/sys/class/net/'//trim(iface)//'/wireless',exist=exists)
    if(exists.or.index(iface,'wl')==1.or.index(iface,'wlan')==1) then
      name='WLAN';return
    end if
    if(index(iface,'tun')==1.or.index(iface,'tap')==1.or.index(iface,'wg')==1.or. &
        index(iface,'lnv')==1.or.index(iface,'tailscale')==1.or.index(iface,'vpn')>0.or. &
        index(iface,'nord')>0.or.index(iface,'proton')>0.or.index(iface,'ppp')==1.or. &
        index(iface,'zt')==1.or.index(iface,'warp')==1.or. &
        trim(typ)=='65534'.or.trim(typ)=='768'.or.trim(typ)=='769') then
      name='VPN';return
    end if
    if(index(iface,'eth')==1.or.index(iface,'en')==1) name='Ethernet'
  end function

  subroutine load_network()
    character(kind=c_char)::buf(32768)
    character(len=32768)::data
    character(len=512)::line,iface,addr,family,oldaddr
    character(len=512)::labels(128)
    integer::i,n,p,k,nseen,j
    data='';buf=c_null_char
    n=int(bf_ifaddrs(buf,int(size(buf),c_int)))
    if(n>0) then
      do i=1,n
        data(i:i)=buf(i)
      end do
    end if
    p=1;nseen=0;labels=''
    do
      call next_line(data,p,line)
      if(len_trim(line)==0) exit
      iface=token_csv(line,1,'|')
      family=token_csv(line,2,'|')
      addr=token_csv(line,3,'|')
      if(family=='6'.and..not.show_ipv6) then
        if(index(data,trim(iface)//'|4|')>0) cycle
      end if
      if(index(iface,'veth')==1.or.index(iface,'docker')==1.or.index(iface,'br-')==1) cycle
      if(nseen>=size(labels)) exit
      if(len_trim(addr)==0) cycle
      oldaddr=trim(iface)//'|'//trim(addr)
      if(any(labels(1:nseen)==oldaddr)) cycle
      nseen=nseen+1; labels(nseen)=oldaddr
      call add(NETWORK,trim(network_class(iface))//' '//trim(iface), &
           'IPv'//trim(family)//'  '//trim(addr))
    end do
    if(g(NETWORK)%count==0) call add(NETWORK,'Interfaces','No assigned IP addresses detected')
  end subroutine

  function token_csv(s,n,delimiter) result(v)
    character(len=*),intent(in)::s,delimiter
    integer,intent(in)::n
    character(len=512)::v
    integer::p,k,q,j
    p=1;v=''
    do k=1,n
      q=index(s(p:),delimiter)
      if(q==0) then
        if(k==n) v=trim(s(p:))
        exit
      end if
      if(k==n) then
        v=trim(s(p:p+q-2));exit
      end if
      p=p+q
    end do
  end function

  integer function count_dirs(path) result(count)
    character(len=*),intent(in)::path
    count=max(0,int(bf_dircount(trim(path)//c_null_char)))
  end function

  subroutine load_packages()
    character(len=512)::s,line,home
    integer::n,system_flat,user_flat,u,ios,i
    n=count_dirs('/var/lib/pacman/local')
    if(n>0) call add(PACKAGES,'Pacman',trim(num(n))//' packages')
    if(n==0) then
      n=0
      open(newunit=u,file='/var/lib/dpkg/status',status='old',action='read',iostat=ios)
      if(ios==0) then
        do
          read(u,'(A)',iostat=ios) line
          if(ios/=0) exit
          if(trim(line)=='Status: install ok installed') n=n+1
        end do
        close(u)
        call add(PACKAGES,'DPKG',trim(num(n))//' installed packages')
      end if
    end if
    system_flat=count_dirs('/var/lib/flatpak/app')
    home=env('HOME')
    user_flat=0
    if(len_trim(home)>0) user_flat=count_dirs(trim(home)//'/.local/share/flatpak/app')
    if(system_flat>0.or.user_flat>0) then
      call add(PACKAGES,'Flatpak',trim(num(system_flat))//' system / '//trim(num(user_flat))//' user apps')
    end if
    if(g(PACKAGES)%count==0) call add(PACKAGES,'Packages','No supported local package DB found')
  end subroutine

  subroutine load_sensors()
    character(len=32768)::s
    character(len=512)::hw,base,name,label,raw,path,kind,unit,val
    character(len=180)::sensor_name
    integer::pos,j,ios,mt,count
    real(real64)::temp
    count=0
    s=list_dir('/sys/class/hwmon');pos=1
    do
      call next_line(s,pos,hw)
      if(len_trim(hw)==0) exit
      if(index(hw,'hwmon')/=1) cycle
      base='/sys/class/hwmon/'//trim(hw)//'/'
      name=first(trim(base)//'name')
      do j=1,24
        raw=first(trim(base)//'temp'//trim(num(j))//'_input')
        if(len_trim(raw)==0) cycle
        read(raw,*,iostat=ios) mt
        if(ios/=0) cycle
        temp=real(mt,real64)/1000.0_real64
        if(temp<=0.or.temp>130) cycle
        label=first(trim(base)//'temp'//trim(num(j))//'_label')
        kind='Sensor'
        select case(trim(name))
        case('k10temp','zenpower','coretemp','cpu_thermal');kind='CPU'
        case('amdgpu','nouveau','i915');kind='GPU'
        case('nvme');kind='NVMe'
        case('thinkpad','acpitz','pch_cannonlake','nct6775');kind='Board'
        end select
        sensor_name=trim(kind)
        if(len_trim(label)>0.and.trim(label)/='temp'//trim(num(j))) then
          sensor_name=trim(kind)//' ('//trim(label)//')'
        else if(j>1) then
          sensor_name=trim(kind)//' ('//trim(name)//' '//trim(num(j))//')'
        end if
        val=trim(fixed(temp))//' °C'
        call add(HEALTH,trim(sensor_name),trim(val),merge(2,0,temp>=90))
        detected_temps=.true.
        count=count+1
        if(temp>=90) call warn('High '//trim(sensor_name)//' temperature: '//trim(val))
        if(count>=18) exit
      end do
      if(count>=18) exit
    end do
    if(.not.detected_temps) then
      ! Fallback thermal zones are readable without lm_sensors or sensors-detect.
      s=list_dir('/sys/class/thermal');pos=1
      do
        call next_line(s,pos,hw)
        if(len_trim(hw)==0) exit
        if(index(hw,'thermal_zone')/=1) cycle
        base='/sys/class/thermal/'//trim(hw)//'/'
        name=first(trim(base)//'type')
        if(index(name,'cpu')==0.and.index(name,'x86_pkg_temp')==0.and. &
           index(name,'soc_thermal')==0) cycle
        raw=first(trim(base)//'temp')
        read(raw,*,iostat=ios) mt
        if(ios/=0) cycle
        temp=real(mt,real64)/1000.0_real64
        if(temp<=0.or.temp>130) cycle
        call add(HEALTH,'CPU ('//trim(name)//')',trim(fixed(temp))//' °C',merge(2,0,temp>=90))
        detected_temps=.true.
        if(temp>=90) call warn('High CPU temperature: '//trim(fixed(temp))//' °C')
        exit
      end do
    end if
    if(.not.detected_temps) call add(HEALTH,'Temperatures','Unavailable — try --temp-help',3)
  end subroutine

  subroutine load_battery()
    character(len=32768)::s
    character(len=512)::item,base,raw,state,full_s,design_s
    integer::pos,capacity,ios,health_pc
    integer(int64)::full,design
    s=list_dir('/sys/class/power_supply');pos=1
    do
      call next_line(s,pos,item)
      if(len_trim(item)==0) exit
      if(index(item,'BAT')/=1) cycle
      base='/sys/class/power_supply/'//trim(item)//'/'
      raw=first(trim(base)//'capacity')
      read(raw,*,iostat=ios) capacity
      if(ios/=0) cycle
      state=first(trim(base)//'status')
      raw=trim(num(capacity))//'% '//trim(state)
      full_s=first(trim(base)//'energy_full')
      design_s=first(trim(base)//'energy_full_design')
      if(len_trim(full_s)==0.or.len_trim(design_s)==0) then
        full_s=first(trim(base)//'charge_full')
        design_s=first(trim(base)//'charge_full_design')
      end if
      read(full_s,*,iostat=ios) full
      if(ios==0) then
        read(design_s,*,iostat=ios) design
        if(ios==0.and.design>0) then
          health_pc=nint(100.0_real64*real(full,real64)/real(design,real64))
          raw=trim(raw)//' ('//trim(num(health_pc))//'% design capacity)'
          if(health_pc<70) call warn('Battery design capacity is '//trim(num(health_pc))//'%')
        end if
      end if
      call add(HEALTH,'Battery '//trim(item),trim(raw))
    end do
  end subroutine

  subroutine temp_help()
    character(len=256)::distro,cmd
    distro=os_value('ID')
    select case(trim(distro))
    case('arch','manjaro','endeavouros');cmd='sudo pacman -S --needed lm_sensors'
    case('ubuntu','debian','linuxmint','pop');cmd='sudo apt install lm-sensors'
    case('fedora','rhel','centos');cmd='sudo dnf install lm_sensors'
    case default;cmd='Install the lm_sensors / lm-sensors package for your distribution.'
    end select
    print '(A)', 'Boopfetch temperature monitoring'
    print '(A)', 'The binary already reads /sys/class/hwmon and /sys/class/thermal directly.'
    print '(A)', 'For broader sensor discovery, optionally install lm_sensors:'
    print '(A)', '    '//trim(cmd)
    print '(A)', 'Then, if needed, run: sudo sensors-detect'
    print '(A)', 'Sensor availability depends on kernel drivers and hardware.'
    print '(A)', 'Installing lm_sensors is NOT required for Boopfetch to run.'
  end subroutine

  subroutine install_temps()
    character(len=256)::id,cmd,reply
    integer::ios,status
    id=os_value('ID')
    select case(trim(id))
    case('arch','manjaro','endeavouros');cmd='sudo pacman -S --needed lm_sensors'
    case('ubuntu','debian','linuxmint','pop');cmd='sudo apt install lm-sensors'
    case('fedora','rhel','centos');cmd='sudo dnf install lm_sensors'
    case default
      call temp_help();return
    end select
    print '(A)', 'Optional temperature monitoring package: lm_sensors'
    print '(A)', 'Boopfetch itself does NOT require this package.'
    print '(A)', 'Proposed command: '//trim(cmd)
    write(*,'(A)',advance='no') 'Run the installation command? [y/N] '
    read(*,'(A)',iostat=ios) reply
    if(ios/=0.or.(reply/='y'.and.reply/='Y'.and.reply/='yes')) then
      print '(A)', 'Cancelled.';return
    end if
    call execute_command_line(trim(cmd),wait=.true.,exitstat=status,cmdstat=ios)
    if(ios/=0.or.status/=0) then
      print '(A)', 'Package installation did not succeed. See package-manager output.'
    else
      print '(A)', 'Installation completed. Optional detection: sudo sensors-detect'
    end if
  end subroutine

  ! Colours and geometric drawing are ANSI+Unicode text only. No terminal UI
  ! framework, ncurses, browser, Python, external themes, or runtime library.
  function paint(s,shade) result(out)
    character(len=*),intent(in)::s,shade
    character(:),allocatable::out
    if(use_color) then
      out=ESC//trim(shade)//'m'//s//ESC//'0m'
    else
      out=s
    end if
  end function

  integer function text_width(s) result(n)
    character(len=*),intent(in)::s
    integer::i,b
    n=0;i=1
    do while(i<=len_trim(s))
      if(s(i:i)==achar(27)) then
        i=i+1
        if(i<=len_trim(s)) then
          if(s(i:i)=='[') then
            i=i+1
            do while(i<=len_trim(s))
              b=iachar(s(i:i));i=i+1
              if(b>=64.and.b<=126) exit
            end do
          end if
        end if
      else
        b=iachar(s(i:i))
        if(b<128.or.b>=192) n=n+1
        i=i+1
      end if
    end do
  end function

  function pad(s,n) result(out)
    character(len=*),intent(in)::s
    integer,intent(in)::n
    character(:),allocatable::out
    out=trim(s)//repeat(' ',max(0,n-text_width(s)))
  end function

  function align_center(s,width) result(out)
    character(len=*),intent(in)::s
    integer,intent(in)::width
    character(:),allocatable::out
    integer::left
    left=max(0,(width-text_width(s))/2)
    out=repeat(' ',left)//trim(s)
    out=out//repeat(' ',max(0,width-text_width(out)))
  end function

  subroutine add_blockline(b,s)
    type(category_block),intent(inout)::b
    character(len=*),intent(in)::s
    if(b%count>=maxlines) return
    b%count=b%count+1
    b%lines(b%count)%s=s
  end subroutine

  function framed(content,width) result(out)
    character(len=*),intent(in)::content
    integer,intent(in)::width
    character(:),allocatable::out
    out=paint('│',CYAN)//' '//pad(content,width-4)//' '//paint('│',PURPLE)
  end function

  function box_top(title,icon,width) result(out)
    character(len=*),intent(in)::title,icon
    integer,intent(in)::width
    character(:),allocatable::out
    character(:),allocatable::name
    name=' '//trim(icon)//' '//trim(title)//' '
    out=paint('╭─',CYAN)//paint(name,WHITE)// &
         paint(repeat('─',max(0,width-4-text_width(name))),PURPLE)//paint('╮',PURPLE)
  end function

  function box_bottom(width) result(out)
    integer,intent(in)::width
    character(:),allocatable::out
    out=paint('╰',CYAN)//paint(repeat('─',max(0,width-2)),BLUE)//paint('╯',PURPLE)
  end function

  subroutine build_box(section,width,block)
    integer,intent(in)::section,width
    type(category_block),intent(out)::block
    character(len=700)::value
    character(len=150)::chunk
    character(:),allocatable::prefix,line,remaining,part,shade
    integer::i,k,available,keysize,n,w,partlen,cut
    block%count=0
    call add_blockline(block,box_top(trim(g(section)%name),trim(g(section)%symbol),width))
    keysize=min(23,max(13,width/4))
    available=width-4-keysize-3
    if(available<16) then
      keysize=max(8,keysize-(16-available))
      available=width-4-keysize-3
    end if
    if(g(section)%count==0) then
      call add_blockline(block,framed(paint('No information available',MUTED),width))
    end if
    do i=1,g(section)%count
      remaining=trim(g(section)%entries(i)%value)
      k=0
      do
        if(len(remaining)==0) exit
        n=len(remaining)
        partlen=min(n,available)
        if(n>available) then
          cut=index(remaining(:partlen),' ',back=.true.)
          if(cut>max(1,available/2)) partlen=cut-1
        end if
        part=remaining(:partlen)
        if(len_trim(part)==0) part=' '
        if(i>0.and.k==0) then
          prefix=paint(trim(g(section)%entries(i)%label),CYAN)// &
              repeat(' ',max(0,keysize-text_width(trim(g(section)%entries(i)%label))))//paint(' : ',MUTED)
        else
          prefix=repeat(' ',keysize)//'   '
        end if
        select case(g(section)%entries(i)%level)
        case(1);shade=GREEN
        case(2);shade=RED
        case(3);shade=GOLD
        case default;shade=WHITE
        end select
        line=prefix//paint(trim(part),shade)
        call add_blockline(block,framed(line,width))
        k=k+1
        if(partlen>=n) exit
        remaining=trim(adjustl(remaining(partlen+1:)))
        if(k>15) exit
      end do
    end do
    call add_blockline(block,box_bottom(width))
  end subroutine

  subroutine build_stack(section_ids,width,stack)
    integer,intent(in)::section_ids(:),width
    type(category_block),intent(out)::stack
    type(category_block)::part
    integer::i,j
    stack%count=0
    do i=1,size(section_ids)
      call build_box(section_ids(i),width,part)
      if(i>1) call add_blockline(stack,repeat(' ',width))
      do j=1,part%count
        call add_blockline(stack,trim(part%lines(j)%s))
      end do
    end do
  end subroutine

  function stack_line(block,index,width) result(line)
    type(category_block),intent(in)::block
    integer,intent(in)::index,width
    character(:),allocatable::line
    if(index>=1.and.index<=block%count) then
      line=pad(trim(block%lines(index)%s),width)
    else
      line=repeat(' ',width)
    end if
  end function

  subroutine cat_logo(art,n)
    character(len=80),intent(out)::art(:)
    integer,intent(out)::n
    art='';n=0
    if(trim(logo_path)/='') then
      call cat_from_file(art,n)
      if(n>0) return
    end if
    if(logo_opt=='none') return
    if(logo_opt=='loader') then
      n=11
      art(1)='         __'
      art(2)='    ____/  \____'
      art(3)='   /  _ BOOP _  \'
      art(4)='  /__/_______\__\'
      art(5)='  |  []   []   |'
      art(6)='  |  === ===   |____'
      art(7)='  |____________|   \'
      art(8)='  (O)        (O)---O'
      art(9)='   \______________/'
      art(10)='      BOOPFETCH'
      art(11)='       LINUX'
    else
      n=14
      art(1)='     /\       /\'
      art(2)='    /  \_____/  \'
      art(3)='   /             \'
      art(4)='  |   ^       ^   |'
      art(5)='  |   o       o   |'
      art(6)='  |       w       |'
      art(7)='   \   \_____/   /'
      art(8)='    \___________/'
      art(9)='    /|  _____  |\'
      art(10)='   / | |     | | \'
      art(11)='  (  | |_____| |  )'
      art(12)='   \_|_________|_/'
      art(13)='      BOOPFETCH'
      art(14)='     =^.^= Linux'
    end if
  end subroutine

  subroutine cat_from_file(art,n)
    character(len=80),intent(out)::art(:)
    integer,intent(out)::n
    integer::u,ios
    n=0
    open(newunit=u,file=trim(logo_path),status='old',action='read',iostat=ios)
    if(ios/=0) return
    do
      if(n>=size(art)) exit
      read(u,'(A)',iostat=ios) art(n+1)
      if(ios/=0) exit
      n=n+1
    end do
    close(u)
  end subroutine

  subroutine make_sidebar(width,height,block)
    integer,intent(in)::width,height
    type(category_block),intent(out)::block
    character(len=80)::art(64)
    character(:),allocatable::content
    integer::nart,i,inside,j,startrow
    block%count=0
    call cat_logo(art,nart)
    if(nart==0) return
    inside=width-4
    call add_blockline(block,paint('╭',CYAN)//paint(repeat('─',width-2),PURPLE)//paint('╮',PURPLE))
    startrow=max(2,(height-2-nart)/3)
    do i=1,max(0,height-2)
      j=i-startrow+1
      if(i==1) then
        content=align_center(paint('◆ B O O P ◆',PURPLE),inside)
      else if(j>=1.and.j<=nart) then
        if(j==nart.or.j==nart-1) then
          content=align_center(paint(trim(art(j)),PURPLE),inside)
        else
          content=align_center(paint(trim(art(j)),CYAN),inside)
        end if
      else if(i==height-4) then
        content=align_center(paint('F O R T R A N',WHITE),inside)
      else if(i==height-3) then
        content=align_center(paint('  [ BOOPFETCH ]  ',PURPLE),inside)
      else if(i>height-8) then
        content=align_center(paint(' · · · · · · · · ',MUTED),inside)
      else
        content=repeat(' ',inside)
      end if
      call add_blockline(block,framed(content,width))
    end do
    call add_blockline(block,paint('╰',CYAN)//paint(repeat('─',width-2),PURPLE)//paint('╯',PURPLE))
  end subroutine

  subroutine headline(width)
    integer,intent(in)::width
    character(:),allocatable::name,system_name
    system_name=trim(env('USER'))//'@'//trim(first('/proc/sys/kernel/hostname'))
    name='  B O O P F E T C H   2.0   |   SYSTEM OVERVIEW '
    print '(A)', paint('╭',CYAN)//paint(repeat('─',width-2),PURPLE)//paint('╮',PURPLE)
    print '(A)', framed(paint(name,CYAN),width)
    print '(A)', framed(paint('  '//trim(system_name),MUTED)// &
        repeat(' ',max(1,width-6-text_width(system_name)-27))//paint('FORTRAN  •  LINUX',PURPLE),width)
    print '(A)', paint('├',CYAN)//paint(repeat('─',width-2),PURPLE)//paint('┤',PURPLE)
  end subroutine

  subroutine footer(width)
    integer,intent(in)::width
    character(:),allocatable::msg
    if(warning_n==0) then
      if(width<80) then
        msg=paint('  ♡  Boop!  =^.^=',GREEN)
      else
        msg=paint('  ♡  Boop of the day: ',CYAN)//paint('All monitored checks purring  =^.^=',GREEN)
      end if
    else
      if(width<80) then
        msg=paint('  ♡  '//trim(num(warning_n))//' warning(s)',GOLD)
      else
        msg=paint('  ♡  Boop of the day: ',CYAN)//paint(trim(num(warning_n))//' warning(s) need a little attention',GOLD)
      end if
    end if
    print '(A)', paint('├',CYAN)//paint(repeat('─',width-2),PURPLE)//paint('┤',PURPLE)
    print '(A)', framed(msg,width)
    print '(A)', paint('╰',CYAN)//paint(repeat('─',width-2),PURPLE)//paint('╯',PURPLE)
  end subroutine

  subroutine output_dashboard()
    type(category_block)::left,right,brand,box
    integer::w,side_w,right_w,col_w,cols,i,h,space_width
    character(:),allocatable::row,section_text
    w=max(55,min(220,terminal_width))
    call headline(w)
    if(w>=146) then
      if(logo_opt=='none') then
        side_w=0;space_width=0
      else
        side_w=29;space_width=2
      end if
      right_w=w-side_w-space_width
      col_w=(right_w-2)/2
      call build_stack([HARDWARE,STORAGE,SYSTEM],col_w,left)
      call build_stack([DESKTOP,NETWORK,PACKAGES,HEALTH],right_w-col_w-2,right)
      h=max(left%count,right%count)
      call make_sidebar(side_w,h,brand)
      do i=1,h
        row=''
        if(side_w>0) row=stack_line(brand,i,side_w)//repeat(' ',space_width)
        row=row//stack_line(left,i,col_w)//'  '//stack_line(right,i,right_w-col_w-2)
        print '(A)', trim(row)
      end do
    else
      ! Mobile / narrow terminal: a proper one-column dashboard; no truncation.
      if(logo_opt/='none') then
        call cat_logo_side_small(w)
      end if
      call build_stack([SYSTEM,HARDWARE,DESKTOP,STORAGE,NETWORK,PACKAGES,HEALTH],w,box)
      do i=1,box%count
        print '(A)', trim(box%lines(i)%s)
      end do
    end if
    call footer(w)
    if(health_flag) then
      if(warning_n==0) then
        print '(A)', paint('HEALTH: ',CYAN)//paint('No warnings detected in available checks.',GREEN)
      else
        print '(A)', paint('HEALTH: ',GOLD)//trim(num(warning_n))//' warning(s):'
        do i=1,notice_n
          print '(A)', '  '//paint('! ',RED)//trim(notices(i))
        end do
      end if
      if(.not.detected_temps) print '(A)', 'Temperatures unavailable. Run: boopfetch --temp-help'
      print '(A)', paint('Note: ',MUTED)//'Unavailable checks do not imply a healthy system.'
    end if
  end subroutine

  subroutine cat_logo_side_small(width)
    integer,intent(in)::width
    character(len=80)::art(64)
    integer::n,i
    call cat_logo(art,n)
    if(n<=0) return
    do i=1,n
      if(i>=n-1) then
        print '(A)', align_center(paint(trim(art(i)),PURPLE),width)
      else
        print '(A)', align_center(paint(trim(art(i)),CYAN),width)
      end if
    end do
  end subroutine

  subroutine output_brief()
    integer::section,j
    print '(A)', paint('Boopfetch 2.0.1  =^.^=',PURPLE)
    do section=1,ng
      print '(A)', paint('['//trim(g(section)%name)//']',CYAN)
      do j=1,g(section)%count
        print '(A)', '  '//trim(g(section)%entries(j)%label)//': '// &
             paint(trim(g(section)%entries(j)%value),WHITE)
      end do
    end do
  end subroutine

  function json_escape(s) result(out)
    character(len=*),intent(in)::s
    character(:),allocatable::out
    integer::i,b
    out=''
    do i=1,len_trim(s)
      b=iachar(s(i:i))
      select case(b)
      case(34,92); out=out//achar(92)//s(i:i)
      case(10);out=out//'\n'
      case(13);out=out//'\r'
      case(9);out=out//'\t'
      case(0:8,11:12,14:31);cycle
      case default;out=out//s(i:i)
      end select
    end do
  end function

  subroutine output_json()
    integer::i,j
    print '(A)', '{"program":"boopfetch","version":"2.0.1","sections":['
    do i=1,ng
      if(i>1) print '(A)', ','
      write(*,'(A)',advance='no') '{"name":"'//trim(json_escape(g(i)%name))//'","items":['
      do j=1,g(i)%count
        if(j>1) write(*,'(A)',advance='no') ','
        write(*,'(A)',advance='no') '{"label":"'//trim(json_escape(g(i)%entries(j)%label))// &
            '","value":"'//trim(json_escape(g(i)%entries(j)%value))//'"}'
      end do
      write(*,'(A)',advance='no') ']}'
    end do
    print '(A)', '],"warnings":['
    do i=1,notice_n
      if(i>1) write(*,'(A)',advance='no') ','
      write(*,'(A)',advance='no') '"'//trim(json_escape(notices(i)))//'"'
    end do
    print '(A)', ']}'
  end subroutine
end module

program main
  use boopfetch,only: run
  implicit none
  call run()
end program
