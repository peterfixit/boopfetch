#!/bin/sh
# Boopfetch 2.0.1 self-contained binary installer (no compiler required).
set -eu
usage() {
  cat <<'USAGE'
Usage: ./install.sh [--no-path] [--help]
  --no-path  Install the executable without editing shell startup files.
  --help     Display this help.
USAGE
}
EDIT_PATH=1
case "${1-}" in
  '') ;;
  --no-path) EDIT_PATH=0 ;;
  -h|--help) usage; exit 0 ;;
  *) usage >&2; exit 2 ;;
esac
HERE=$(CDPATH='' cd -- "$(dirname -- "$0")" && pwd)
DEST=${HOME:?HOME must be set}/.local/bin
BIN="$HERE/bin/boopfetch"
if [ ! -f "$BIN" ]; then
  BIN="$HERE/build/boopfetch-static"
fi
if [ ! -f "$BIN" ]; then
  printf '%s\n' 'Static binary is missing. Build it with make static (requires GCC/gfortran), or download the complete release archive.' >&2
  exit 1
fi
mkdir -p "$DEST"
cp "$BIN" "$DEST/boopfetch"
chmod 755 "$DEST/boopfetch"

# One idempotent, guarded entry; no duplicate PATH directories on repeated logins.
PATH_LINE='case ":$PATH:" in *":$HOME/.local/bin:"*) ;; *) export PATH="$HOME/.local/bin:$PATH" ;; esac'
add_path_entry() {
  rc=$1
  if [ -f "$rc" ] && grep -Fqx "$PATH_LINE" "$rc"; then
    return
  fi
  # Ensure trailing newline so existing comments are not modified.
  if [ -f "$rc" ]; then printf '\n' >> "$rc"; fi
  printf '%s\n' '# Boopfetch user-installed executable directory' "$PATH_LINE" >> "$rc"
  printf 'Updated shell configuration: %s\n' "$rc"
}
if [ "$EDIT_PATH" -eq 1 ]; then
  case "${SHELL##*/}" in
    zsh)
      add_path_entry "${ZDOTDIR:-$HOME}/.zshrc"
      ACTIVATE='. ~/.zshrc'
      ;;
    *)
      # Bash non-login terminals read .bashrc; login terminals read first of
      # .bash_profile, .bash_login, .profile.
      add_path_entry "$HOME/.bashrc"
      if [ -f "$HOME/.bash_profile" ]; then
        add_path_entry "$HOME/.bash_profile"
      elif [ -f "$HOME/.bash_login" ]; then
        add_path_entry "$HOME/.bash_login"
      else
        add_path_entry "$HOME/.profile"
      fi
      ACTIVATE='. ~/.bashrc'
      ;;
  esac
fi
printf '\nInstalled Boopfetch to %s\n' "$DEST/boopfetch"
printf '%s\n' 'It can run immediately using its full path:'
printf '  %s\n' "$DEST/boopfetch --health"
if [ "$EDIT_PATH" -eq 1 ]; then
  printf '%s\n' 'For the current terminal, activate the updated PATH once:'
  printf '  %s\n' "$ACTIVATE"
  printf '%s\n' 'New terminals will find the boopfetch command automatically.'
else
  printf '%s\n' 'Shell PATH was not changed (--no-path).'
fi
