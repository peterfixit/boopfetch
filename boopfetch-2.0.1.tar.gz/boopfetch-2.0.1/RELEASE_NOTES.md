# Boopfetch 2.0.1 — installer update

## Changes since 2.0.0

- Installer now automatically configures `~/.local/bin` in the user’s shell PATH.
- Bash interactive and login startup files are handled; Zsh is supported via `.zshrc`.
- Shell configuration updates are safe to repeat (no duplicate PATH entries).
- Adds `--no-path` for users who do not want their shell configuration edited.
- Installation instructions explicitly include `source ~/.bashrc` to activate the
  change in an already open terminal; an executed script cannot update its parent shell.
- Rebuilds the same self-contained Fortran/Linux program with an updated version number.
- No new runtime dependencies.

## Known limitations

- x86-64 Linux only for the provided static binary.
- Availability of GPU and temperature sensors depends on local Linux kernel drivers.
- The failed-systemd-services row is deliberately marked not queried.
