#!/usr/bin/env bash
set -eu
cd "$(dirname "$0")/.."
B=build/boopfetch-static
[ -x "$B" ] || { echo "Static binary missing" >&2; exit 1; }
file "$B" | grep -q 'statically linked'
if readelf -d "$B" 2>/dev/null | grep -q NEEDED; then echo 'FAIL: dynamic dependencies' >&2; exit 1; fi
[ "$("$B" --version)" = 'Boopfetch 2.0.1 (Fortran, Linux, standalone)' ]
"$B" --help | grep -q -- '--temp-help'
"$B" --temp-help | grep -q 'lm_sensors\|lm-sensors'
"$B" --brief | grep -q 'CPU:'
"$B" --brief | grep -q '^  /:'
"$B" --brief | grep -q 'IPv4\|No assigned IP addresses'
"$B" --brief | grep -q 'Health checks:'
"$B" --logo=loader --width=95 --plain | grep -q 'BOOP'
"$B" --logo=none --width=70 --plain | grep -q 'Storage'
"$B" --logo=boop --width=160 --plain | grep -q '╭─ ▣ Hardware'
"$B" --warn-disk=99 --health --brief | grep -q 'warning'
"$B" --ipv6 --brief >/dev/null
"$B" --json | python3 -c 'import json,sys; x=json.load(sys.stdin); assert x["program"]=="boopfetch" and len(x["sections"])==7;print("JSON OK")'
# /run and /sys are not shown as mount rows.
if "$B" --brief | grep -E '^  (/run|/sys|/proc|/dev):'; then echo 'FAIL: pseudo mount shown' >&2; exit 1; fi
# Previous business branding must not appear, including in the binary.
if "$B" --plain | grep -i "P""M""H""S"; then echo 'FAIL: old branding remains' >&2;exit 1;fi
if strings "$B" | grep -i "P""M""H""S"; then echo 'FAIL: old branding linked in binary' >&2; exit 1;fi
# Invalid CLI flags must exit nonzero.
if "$B" --logo=obsolete >/dev/null 2>&1; then echo 'FAIL: obsolete logo accepted' >&2; exit 1; fi
if "$B" --warn-disk=0 >/dev/null 2>&1; then echo 'FAIL: invalid threshold accepted' >&2; exit 1; fi
if "$B" --width=5 >/dev/null 2>&1; then echo 'FAIL: invalid width accepted' >&2; exit 1; fi
printf 'All Boopfetch v2.0.1 regression tests passed.\n'
