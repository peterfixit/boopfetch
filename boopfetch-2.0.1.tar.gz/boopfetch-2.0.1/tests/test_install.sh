#!/usr/bin/env bash
# Installer regression tests; run from the project root after make static.
set -euo pipefail
cd "$(dirname "$0")/.."
T=$(mktemp -d)
trap 'rm -rf "$T"' EXIT
mkdir -p "$T/home"
: > "$T/home/.bashrc"
: > "$T/home/.profile"
HOME="$T/home" SHELL=/bin/bash ./install.sh >/dev/null
HOME="$T/home" SHELL=/bin/bash ./install.sh >/dev/null
PATH_LINE='case ":$PATH:" in *":$HOME/.local/bin:"*) ;; *) export PATH="$HOME/.local/bin:$PATH" ;; esac'
[ "$(grep -Fxc "$PATH_LINE" "$T/home/.bashrc")" -eq 1 ]
[ "$(grep -Fxc "$PATH_LINE" "$T/home/.profile")" -eq 1 ]
HOME="$T/home" bash -c '. "$HOME/.bashrc"; test "$(command -v boopfetch)" = "$HOME/.local/bin/boopfetch"; boopfetch --version' | grep -q 'Boopfetch 2.0.1'
mkdir -p "$T/noedit"
HOME="$T/noedit" SHELL=/bin/bash ./install.sh --no-path >/dev/null
[ -x "$T/noedit/.local/bin/boopfetch" ]
[ ! -e "$T/noedit/.bashrc" ]
mkdir -p "$T/zsh"
HOME="$T/zsh" SHELL=/bin/zsh ./install.sh >/dev/null
[ -f "$T/zsh/.zshrc" ]
echo 'Installer regression tests passed.'
